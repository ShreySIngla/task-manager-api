# Task Manager API (Django + DRF)

This is a complete Django REST Framework implementation of the Task Manager API 
It includes JWT authentication, Swagger docs, pagination, filtering, basic unit tests, and instructions to run locally.


## Quick setup (Linux)

```bash
# unzip this project or clone repository
python3 -m venv myenv
source myenv/bin/activate
pip install -r requirements.txt

# apply migrations and create superuser
python manage.py migrate
python manage.py createsuperuser

# run server
python manage.py runserver 0.0.0.0:8000
```

## Endpoints

- `POST /api/auth/register/` — register (username, email, password)
- `POST /api/auth/token/` — JWT token obtain (username, password)
- `POST /api/auth/token/refresh/` — refresh token
- `GET /api/tasks/` — list tasks (paginated)
- `POST /api/tasks/` — create task (auth required)
- `GET /api/tasks/{id}/` — retrieve
- `PUT /api/tasks/{id}/` — update (owner only)
- `DELETE /api/tasks/{id}/` — delete (owner only)
- Swagger UI: `/swagger/` or `/`
- ReDoc UI: `/redoc/`

## Tests

Run with Django test runner or pytest:

```bash
python manage.py test
# or with pytest (if installed)
pytest -q
```

## Notes

- Uses Simple JWT for authentication.
- By default `/api/tasks/` returns tasks owned by the authenticated user.
- Adjust `config/settings.py` for DB and production settings (SECRET_KEY, DEBUG, ALLOWED_HOSTS).
