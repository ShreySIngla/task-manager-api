from django.urls import reverse
from rest_framework.test import APITestCase
from django.contrib.auth import get_user_model
from rest_framework import status
from .models import Task
from rest_framework_simplejwt.tokens import RefreshToken

User = get_user_model()

def get_tokens_for_user(user):
    refresh = RefreshToken.for_user(user)
    return {'refresh': str(refresh), 'access': str(refresh.access_token)}

class TaskAPITest(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='tester', password='pass')
        self.user2 = User.objects.create_user(username='other', password='pass')
        self.token = get_tokens_for_user(self.user)['access']

    def auth_header(self):
        return {'HTTP_AUTHORIZATION': f'Bearer {self.token}'}

    def test_create_task(self):
        url = reverse('task-list')
        data = {'title': 'Test task', 'description': 'desc'}
        response = self.client.post(url, data, format='json', **self.auth_header())
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(Task.objects.count(), 1)
        task = Task.objects.first()
        self.assertEqual(task.owner, self.user)

    def test_cannot_modify_other_user_task(self):
        task = Task.objects.create(owner=self.user2, title='Other task')
        url = reverse('task-detail', kwargs={'pk': task.pk})
        data = {'title': 'hacked'}
        response = self.client.put(url, data, format='json', **self.auth_header())
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)
